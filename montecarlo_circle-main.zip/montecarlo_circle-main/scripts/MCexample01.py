import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt 
from matplotlib.patches import Circle 
import random 

#area of a circle = pi * r^2
#area of a square = 4 * r^2
#x = 1 
#y = 1
#boundaries: y=1 amd x=1 

def estimate_pi(n_square):
    """Function to estimate pi using MC"""
    #seed the random number generator
    n_circle = 0 
    for i in range(n_square):
    #Generate random point x
        x = random.uniform(-1,1) 
    #"""Generate random point y"""
        y = random.uniform(-1,1)
        if x**2 + y**2 <= 1:
        #increments for random movements 
            n_circle += 1
    pi_estimate = 4 * n_circle / n_square 
    return pi_estimate

def main():
    """Run function via estimation"""
    pi_estimate = estimate_pi(10000)
    print("estimated vlaue of pi:", pi_estimate)

    #Plot MC sampling profile:
    n_samples = 10000
    pi = 3.14159265358979323846
    fig, ax = plt.subplots()
    plt.axhline(y=pi, color='r', linestyle='--')
    x_axis = np.arange(n_samples)
    y_axis = [estimate_pi(int(n + 1)) for n in x_axis]

    #Check if the number of points is as expected
    print(f"The number of points is: {len(x_axis)} and we expected {n_samples}")
    plt.plot(x_axis, y_axis, 'b', label='Estimated value of pi')
    plt.show()
    plt.savefig("MCexample01.png")

if __name__ == '__main__':
    main()